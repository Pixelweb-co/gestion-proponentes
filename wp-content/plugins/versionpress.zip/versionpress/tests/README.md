# VersionPress tests

See [Dev-Setup.md#testing](../../../docs/content/en/developer/dev-setup.md#testing).
